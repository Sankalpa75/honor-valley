<div id="owl-demo" class="owl-carousel owl-theme">

    <div class="item">
        <div class="banner-content">
            <img src="images/b1.jpg">
            <div class="centered  hidden-xs">
                <h1>Honor Valley Fruits. <br> Fresh Fruits Delivery Service.</h1>
                <p>Frest Fruits delivered right at your doorstep.</p> <br>
                <a href="./about"><button class="button1">Learn More</button></a>
            </div>
        </div>
    </div>

    <div class="item">
        <div class="banner-content">
            <img src="images/b2.jpg">
            <div class="centered  hidden-xs">
                <h1>Honor Valley Fruits. <br> Fresh Fruits Delivery Service.</h1>
                <p>Frest Fruits delivered right at your doorstep.</p> <br>
                <a href="./about"><button class="button1">Learn More</button></a>
            </div>
        </div>
    </div>

    <div class="item">
        <div class="banner-content">
            <img src="images/b3.jpg">
            <div class="centered  hidden-xs">
                <h1>Honor Valley Fruits. <br> Fresh Fruits Delivery Service.</h1>
                <p>Frest Fruits delivered right at your doorstep.</p> <br>
                <a href="./about"><button class="button1">Learn More</button></a>
            </div>
        </div>
    </div>

    <div class="item">
        <div class="banner-content">
            <img src="images/b4.jpg">
            <div class="centered  hidden-xs">
                <h1>Honor Valley Fruits. <br> Fresh Fruits Delivery Service.</h1>
                <p>Frest Fruits delivered right at your doorstep.</p> <br>
                <a href="./about"><button class="button1">Learn More</button></a>
            </div>
        </div>
    </div>

</div>